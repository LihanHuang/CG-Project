#ifndef HEAT_H
#define HEAT_H

#include <cmath>
#include <Eigen/Dense>
#include <Eigen/Sparse>
using namespace Eigen;

class Heat
{
public:
    Heat();
    ~Heat();

    void setSources(VectorXi indices_);
    void setVertices(const Matrix3Xf vertices_);
    void setFaces(Matrix3Xi faces_);
    void setTime(float t);

    VectorXf getDistances();
    MatrixXf getSIHKS();

    inline double cotAngle(Vector3f a, Vector3f b)
    {
        double angle = acos(a.dot(b)/(a.norm()*b.norm()));
        return 1/tan(angle);
    }

private:
    int nvertices;
    int nfaces;
    Matrix3Xf vertices; // (3, nvertices)
    Matrix3Xi faces; // (3, nfaces)
    Matrix3Xf normals; // (3, nfaces)
    SparseMatrix<float> DeltaCot; // (nvertices, nvertices)

    SparseMatrix<float> Delta; // (nvertices, nvertices)
    SparseMatrix<float> GradMatX;
    SparseMatrix<float> GradMatY;
    SparseMatrix<float> GradMatZ;
    SparseMatrix<float> DivMatX;
    SparseMatrix<float> DivMatY;
    SparseMatrix<float> DivMatZ;

    VectorXf areas; // (nfaces)
    SparseMatrix<float> diagAreas;
    VectorXf delta; // (nvertices)
    float time;

    VectorXf distances; // (nvertices)
    void getNormalsAreas();
    void buildGradDivMat();
    void buildDeltaCot();
    void eigenDeltaCot();
    void computeDistances();

    // for SIHKS
    VectorXf timescale;
    VectorXf freqscale;
    float alpha = 2; // log_alpha
    MatrixXcf evecs; // (nvertices, k)
    VectorXcf evals;
    MatrixXf tSIHKS; // (nvertices, times)
    MatrixXf fSIHKS; // (nvertices, freqs)

    void buildSIHKS();
};

#endif // HEAT_H
