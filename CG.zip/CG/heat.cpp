#include "heat.h"
#include <iostream>
#include <vector>

#include <Spectra/SymEigsShiftSolver.h>
#include <Spectra/MatOp/SparseSymShiftSolve.h>
using namespace Spectra;

Heat::Heat()
{
    timescale.resize(96);
    for (int i=0; i<96; i++)
        timescale(i) = 1+0.2*i;
    freqscale.resize(19);
    for (int i=0; i<19; i++)
        freqscale(i) = 2+i;
}

Heat::~Heat()
{

}

void Heat::setVertices(const Matrix3Xf vertices_)
{
    vertices = vertices_;
    nvertices = vertices_.cols();
}

void Heat::setFaces(Matrix3Xi faces_)
{
    faces = faces_;
    nfaces = faces_.cols();
    Matrix3Xf temp_normal(3,nfaces);
    normals = temp_normal;
    VectorXf temp_area(nfaces);
    areas = temp_area;
}

void Heat::setSources(VectorXi indices_)
{
    delta.resize(vertices.cols());
    for (int iter=0; iter<vertices.cols(); iter++)
        delta(iter)=0;
    for (int iter = 0; iter < indices_.size(); iter++)
    {
        delta(indices_(iter)) = 1;
    }
    // std::cout << delta.norm() << std::endl;
}

void Heat::setTime(float t)
{
    time = t;
}

VectorXf Heat::getDistances()
{
    getNormalsAreas();
    buildGradDivMat();
    buildDeltaCot();
    computeDistances();

    float dmax = distances.maxCoeff();
    float dmin = distances.minCoeff();
    for (int iter = 0; iter < nvertices; iter++)
        distances(iter) = (distances(iter) - dmin)/(dmax - dmin);

    return distances;
}

void Heat::getNormalsAreas()
{
    for (int iterF = 0; iterF < nfaces; iterF++)
    {
        Vector3f vec0 = vertices.col(faces.col(iterF)(0));
        Vector3f vec1 = vertices.col(faces.col(iterF)(1));
        Vector3f vec2 = vertices.col(faces.col(iterF)(2));
        Vector3f vec = (vec1 - vec0).cross(vec2 - vec1);
        areas(iterF) = vec.norm()/2;
        normals.col(iterF) = vec/vec.norm();
    }
}

void Heat::buildGradDivMat()
{
    VectorXi I(3*nfaces), J(3*nfaces);
    Matrix3Xf V(3, 3*nfaces);
    for (int iter=0; iter<3; iter++)
    {
        // iter from 0 to 2
        int s = (iter+1)%3;
        int t = (iter+2)%3;

        for (int iterF = 0; iterF < nfaces; iterF++)
        {
            Vector3f vecs = vertices.col(faces.col(iterF)(s));
            Vector3f vect = vertices.col(faces.col(iterF)(t));
            I(iter*nfaces+iterF) = iterF;
            J(iter*nfaces+iterF) = faces.row(iter)(iterF);
            V.col(iter*nfaces+iterF) = normals.col(iterF).cross(vect - vecs);
        }
    }

    SparseMatrix<float> dA(nfaces, nfaces), dAInv(nfaces, nfaces);
    for (int iterF = 0; iterF < nfaces; iterF++)
    {
        dA.insert(iterF, iterF) = 1/(2*areas(iterF));
        dAInv.insert(iterF, iterF) = (2*areas(iterF));
    }

    SparseMatrix<float> MatX(nfaces, nvertices), MatY(nfaces, nvertices), MatZ(nfaces, nvertices);
    std::vector< Triplet<float> > tripletList1, tripletList2, tripletList3;
    for (int iterF = 0; iterF < 3*nfaces; iterF++)
    {
        int i = I(iterF);
        int j = J(iterF);
        tripletList1.push_back(Triplet<float>(i,j, V.row(0)(iterF)));
        tripletList2.push_back(Triplet<float>(i,j, V.row(1)(iterF)));
        tripletList3.push_back(Triplet<float>(i,j, V.row(2)(iterF)));
    }
    MatX.setFromTriplets(tripletList1.begin(), tripletList1.end());
    MatY.setFromTriplets(tripletList2.begin(), tripletList2.end());
    MatZ.setFromTriplets(tripletList3.begin(), tripletList3.end());

    GradMatX = dA*MatX;
    GradMatY = dA*MatY;
    GradMatZ = dA*MatZ;

    DivMatX = GradMatX.transpose()*dAInv;
    DivMatY = GradMatY.transpose()*dAInv;
    DivMatZ = GradMatZ.transpose()*dAInv;

    Delta = DivMatX*GradMatX + DivMatY*GradMatY + DivMatZ*GradMatZ;
}

void Heat::buildDeltaCot()
{
    VectorXi I(6*nfaces), J(6*nfaces);
    VectorXf V(6*nfaces);
    VectorXi II(3*nfaces);
    VectorXf VV(3*nfaces);
    for (int iter=0; iter<3; iter++)
    {
        // iter from 0 to 2
        int s = (iter+1)%3;
        int t = (iter+2)%3;

        for (int iterF = 0; iterF < nfaces; iterF++)
        {
            Vector3f veci = vertices.col(faces.col(iterF)(iter));
            Vector3f vecs = vertices.col(faces.col(iterF)(s));
            Vector3f vect = vertices.col(faces.col(iterF)(t));

            I(2*iter*nfaces+iterF) = faces.row(s)(iterF);
            I(2*iter*nfaces+iterF+nfaces) = faces.row(t)(iterF);
            J(2*iter*nfaces+iterF) = faces.row(t)(iterF);
            J(2*iter*nfaces+iterF+nfaces) = faces.row(s)(iterF);
            V(2*iter*nfaces+iterF) = cotAngle(vecs-veci, vect-veci);
            V(2*iter*nfaces+iterF+nfaces) = cotAngle(vecs-veci, vect-veci);
            II(iter*nfaces+iterF) = faces.row(iter)(iterF);
            VV(iter*nfaces+iterF) = areas(iterF);
        }
    }

    SparseMatrix<float> A(nvertices, nvertices);
    std::vector< Triplet<float> > tripletList1;
    for (int iterF = 0; iterF < 3*nfaces; iterF++)
    {
        int i = II(iterF);
        float v = VV(iterF);
        tripletList1.push_back(Triplet<float>(i,i,v));
    }
    A.setFromTriplets(tripletList1.begin(), tripletList1.end());
    diagAreas = A;

    SparseMatrix<float> W(nvertices, nvertices);
    std::vector< Triplet<float> > tripletList2;
    for (int iterF = 0; iterF < 6*nfaces; iterF++)
    {
        int i = I(iterF);
        int j = J(iterF);
        float v = V(iterF);
        tripletList2.push_back(Triplet<float>(i,j,v));
    }
    W.setFromTriplets(tripletList2.begin(), tripletList2.end());

    SparseMatrix<float> Diag(nvertices, nvertices);
    for (int iterV = 0; iterV < nvertices; iterV++)
        Diag.insert(iterV, iterV) = W.col(iterV).sum();
    DeltaCot = Diag - W;
}

void Heat::computeDistances()
{
    VectorXf u(nvertices);
    SparseMatrix<float> A = diagAreas + time*DeltaCot;

    SimplicialLDLT<SparseMatrix<float> > solver1;
    solver1.compute(A);
    if (solver1.info()!=Success)
    {
        std::cout<<"decomposition failed"<<std::endl;
    }
    u = solver1.solve(delta);
    if (solver1.info()!=Success)
    {
        std::cout<<"solving failed"<<std::endl;
    }

    Matrix3Xf g(3,nfaces), h(3,nfaces);
    g.row(0) = (GradMatX*u).transpose();
    g.row(1) = (GradMatY*u).transpose();
    g.row(2) = (GradMatZ*u).transpose();

    for (int iterF = 0; iterF < nfaces; iterF++)
    {
        Vector3f temp = g.col(iterF);
        h.col(iterF) = - g.col(iterF)/temp.norm();
    }
    VectorXf divh = DivMatX*(h.row(0).transpose()) + DivMatY*(h.row(1).transpose()) + DivMatZ*(h.row(2).transpose());

    SimplicialLDLT<SparseMatrix<float> > solver2;
    solver2.compute(Delta);
    if(solver2.info()!=Success)
    {
        std::cout<<"decomposition failed"<<std::endl;
    }
    distances = solver2.solve(divh);
    if(solver2.info()!=Success)
    {
        std::cout<<"solving failed"<<std::endl;
    }

}

void Heat::eigenDeltaCot()
{
    SparseMatrix<float> Laplacian = DeltaCot;
    SparseSymShiftSolve<float> op(Laplacian);
    SymEigsShiftSolver< float, LARGEST_MAGN, SparseSymShiftSolve<float> > eigs(&op, 10, 20, 0.0);

    eigs.init();
    eigs.compute();
    if(eigs.info() == SUCCESSFUL)
    {
        evals = eigs.eigenvalues();
        evecs = eigs.eigenvectors(10);
    }
    // std::cout << evals(0) << std::endl;
}

void Heat::buildSIHKS()
{
    int k = 10;
    tSIHKS.resize(nvertices, 96);
    fSIHKS.resize(nvertices, 19);

    for (int iterT = 0; iterT < tSIHKS.cols(); iterT++)
    {
        VectorXf vec1 = pow(alpha, timescale(iterT))*evals.real();
        VectorXf vec2(k);
        for (int iter = 0; iter < k; iter++)
            vec2(iter) = exp(-pow(alpha, timescale(iterT))*evals(iter).real());
        float factor = vec1.dot(vec2);
        MatrixXf mat1(evecs.rows(), evecs.cols());
        for (int iterR = 0; iterR < evecs.rows(); iterR++)
            for (int iterC = 0; iterC < evecs.cols(); iterC++)
                mat1(iterR, iterC) = (evecs(iterR, iterC).real())*(evecs(iterR, iterC).real());
        for (int iterV = 0; iterV < nvertices; iterV++)
            tSIHKS(iterV, iterT) = -log(alpha)*mat1.row(iterV).sum()*factor;
    }
}

MatrixXf Heat::getSIHKS()
{
    eigenDeltaCot();
    buildSIHKS();

    return tSIHKS;
}
