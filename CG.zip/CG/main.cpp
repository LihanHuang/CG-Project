#include <iostream>
#include <fstream>
#include <vector>
#include <stdexcept>
#include <string>
#include <cstdlib>
using namespace std;

#include <stdio.h>
#include <string.h>

#include <Eigen/Dense>
using namespace Eigen;

#include "Ranger/globals.h"
#include "Ranger/ForestRegression.h"
#include "Ranger/ArgumentHandler.h"

#include <GLUT/glut.h>

#include "heat.h"

GLint winWidth = 450, winHeight = 375;          //  Initial display-window size.
GLfloat x = 0.0, y = -0.0, z = 1.0;             //  Viewing-coordinate origin.
GLfloat xref = 0.0, yref = 0.0, zref = -1.0;    //  Look-at point.
GLfloat Vx = 0.0, Vy = 1.0, Vz = 0.0;           //  View-up vector.
/*  Set coordinate limits for the clipping window:  */
GLfloat xwMin = -0.5, ywMin = -0.5, xwMax = 0.5, ywMax = 0.5;
/*  Set positions for near and far clipping planes:  */
GLfloat dnear = 0.5, dfar = 1.5;

Matrix3Xf vertices;
Matrix3Xi faces;
vector<Vector3f> data;
VectorXf distances;     // normalized HGD
float dmaximum=0, dminimum=0;
float PI = 3.1415926535;
MatrixXf SIHKS;         // SIHKS descriptors
VectorXf normSIHKS;
float nmaximum=0, nminimum=0;
VectorXf vote;          // Voting in Localization
float vmaximum=0, vminimum=0;
VectorXi sources;

VectorXi train_indices;
VectorXi test_indices;

// Random Forest Training
int train()
{
    int c = 17;
    char* vtrain[17] = {"ranger","--outprefix","CG","--seed","1","--memmode","1","--verbose","--write","--file","train.txt","--depvarname","96","--treetype","3","--ntree","30"};
    ArgumentHandler arg_handler(c, vtrain);
    Forest* forest = 0;

    try {
        // Handle command line arguments
        if (arg_handler.processArguments() != 0) {
            return 0;
        }
        arg_handler.checkArguments();

        // Create forest object
        switch (arg_handler.treetype) {
        case TREE_REGRESSION:
            forest = new ForestRegression;
            break;
        }

        // Verbose output to logfile if non-verbose mode
        std::ostream* verbose_out;
        if (arg_handler.verbose) {
            verbose_out = &std::cout;
        } else {
            std::ofstream* logfile = new std::ofstream();
            logfile->open(arg_handler.outprefix + ".log");
            if (!logfile->good()) {
                throw std::runtime_error("Could not write to logfile.");
            }
            verbose_out = logfile;
        }

        // Call Ranger
        *verbose_out << "Starting Ranger." << std::endl;
        forest->initCpp(arg_handler.depvarname, arg_handler.memmode, arg_handler.file, arg_handler.mtry,
                        arg_handler.outprefix, arg_handler.ntree, verbose_out, arg_handler.seed, arg_handler.nthreads,
                        arg_handler.predict, arg_handler.impmeasure, arg_handler.targetpartitionsize, arg_handler.splitweights,
                        arg_handler.alwayssplitvars, arg_handler.statusvarname, arg_handler.replace, arg_handler.catvars,
                        arg_handler.savemem, arg_handler.splitrule, arg_handler.caseweights, arg_handler.predall, arg_handler.fraction,
                        arg_handler.alpha, arg_handler.minprop, arg_handler.holdout, arg_handler.predictiontype,
                        arg_handler.randomsplits);

        forest->run(true);
        if (arg_handler.write) {
            forest->saveToFile();
        }
        forest->writeOutput();
        *verbose_out << "Finished Ranger." << std::endl;

        delete forest;
    } catch (std::exception& e) {
        std::cerr << "Error: " << e.what() << " Ranger will EXIT now." << std::endl;
        delete forest;
        return -1;
    }

    return 0;
}

// Random Forest Testing
int test()
{
    int c = 19;
    char* vtest[19] = {"ranger","--file","test.txt","--outprefix","CG","--seed","1","--memmode","1","--verbose","--write","--depvarname","96","--treetype","3","--ntree","30","--predict", "CG.forest"};
    ArgumentHandler arg_handler(c, vtest);
    Forest* forest = 0;

    try {
        // Handle command line arguments
        if (arg_handler.processArguments() != 0) {
            return 0;
        }
        arg_handler.checkArguments();

        // Create forest object
        switch (arg_handler.treetype) {
        case TREE_REGRESSION:
            forest = new ForestRegression;
            break;
        }

        // Verbose output to logfile if non-verbose mode
        std::ostream* verbose_out;
        if (arg_handler.verbose) {
            verbose_out = &std::cout;
        } else {
            std::ofstream* logfile = new std::ofstream();
            logfile->open(arg_handler.outprefix + ".log");
            if (!logfile->good()) {
                throw std::runtime_error("Could not write to logfile.");
            }
            verbose_out = logfile;
        }

        // Call Ranger
        *verbose_out << "Starting Ranger." << std::endl;
        forest->initCpp(arg_handler.depvarname, arg_handler.memmode, arg_handler.file, arg_handler.mtry,
                        arg_handler.outprefix, arg_handler.ntree, verbose_out, arg_handler.seed, arg_handler.nthreads,
                        arg_handler.predict, arg_handler.impmeasure, arg_handler.targetpartitionsize, arg_handler.splitweights,
                        arg_handler.alwayssplitvars, arg_handler.statusvarname, arg_handler.replace, arg_handler.catvars,
                        arg_handler.savemem, arg_handler.splitrule, arg_handler.caseweights, arg_handler.predall, arg_handler.fraction,
                        arg_handler.alpha, arg_handler.minprop, arg_handler.holdout, arg_handler.predictiontype,
                        arg_handler.randomsplits);

        forest->run(true);
        if (arg_handler.write) {
            forest->saveToFile();
        }
        forest->writeOutput();
        *verbose_out << "Finished Ranger." << std::endl;

        delete forest;
    } catch (std::exception& e) {
        std::cerr << "Error: " << e.what() << " Ranger will EXIT now." << std::endl;
        delete forest;
        return -1;
    }
    return 0;
}

void writeData(MatrixXf X, VectorXf Y, string filename)
{
    ofstream file;
    file.open (filename);
    for (int iter=0; iter<X.cols(); iter++)
        file << iter << ",";
    file << X.cols();
    file << "\n";
    for (int iterR=0; iterR<X.rows(); iterR++)
    {
        for (int iterC=0; iterC<X.cols(); iterC++)
        {
            file << X(iterR, iterC) << ",";
        }
        file << Y(iterR);
        file << "\n";
    }
    file.close();
}

VectorXi sampling(int max, int num)
{
    VectorXi samples(num);
    for (int iter=0; iter<num; iter++)
        samples(iter) = rand() % max;

    return samples;
}

void init (void)
{
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glMatrixMode(GL_MODELVIEW);
    gluLookAt (x, y, z, xref, yref, zref, Vx, Vy, Vz);
    glMatrixMode (GL_PROJECTION);
    glFrustum (xwMin, xwMax, ywMin, ywMax, dnear, dfar);
}

Vector3f colorMap(float scalar)
{
    Vector3f color;
    float a = (1-scalar)/0.25;
    int X = floor(a);
    float Y= (a-X);
    float r=0, g=0, b=0;
    switch(X)
    {
    case 0: r=1;g=Y;b=0;break;
    case 1: r=1-Y;g=1;b=0;break;
    case 2: r=0;g=1;b=Y;break;
    case 3: r=0;g=1-Y;b=1;break;
    case 4: r=0;g=0;b=1;break;
    }
    color(0) = r;
    color(1) = g;
    color(2) = b;
    return color;
}

void displayFcn(void)
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (0.0, 0.0, 0.4);

    glBegin (GL_TRIANGLES);
    for (int i=0; i<data.size(); i++)
    {
        glVertex3f(data[i](0), data[i](1), data[i](2));
    }
    glEnd();

    glColor3f (1.0, 0.4, 0);
    glPointSize(5.0);
    glBegin (GL_POINTS);
    for (int i=0; i<sources.size(); i++)
    {
        glVertex3f(vertices(0,sources(i)), vertices(1,sources(i)), vertices(2,sources(i)));
    }
    glEnd();

    glFlush ( );
}

void displayFcnTrain(void)
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (0.0, 0.0, 0.4);

    glBegin (GL_TRIANGLES);
    for (int i=0; i<data.size(); i++)
    {
        glVertex3f(data[i](0), data[i](1), data[i](2));
    }
    glEnd();

    glColor3f (1.0, 0.4, 0);
    glBegin (GL_POINTS);
    for (int i=0; i<train_indices.size(); i++)
    {
        glVertex3f(vertices(0,train_indices(i)), vertices(1,train_indices(i)), vertices(2,train_indices(i)));
    }
    glEnd();

    glFlush ( );
}

void displayFcnTest(void)
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (0.0, 0.0, 0.4);

    glBegin (GL_TRIANGLES);
    for (int i=0; i<data.size(); i++)
    {
        glVertex3f(data[i](0), data[i](1), data[i](2));
    }
    glEnd();

    glColor3f (1.0, 0.4, 0);
    glPointSize(5.0);
    glBegin (GL_POINTS);
    for (int i=0; i<test_indices.size(); i++)
    {
        glVertex3f(vertices(0,test_indices(i)), vertices(1,test_indices(i)), vertices(2,test_indices(i)));
    }
    glEnd();

    glFlush ( );
}

void displayFcnHGD (void)
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (0.0, 0.0, 0.4);

    glBegin (GL_TRIANGLES);
    for (int i=0; i<faces.cols(); i++)
    {
        int a=0, b=0, c=0;
        a = faces(0,i);
        b = faces(1,i);
        c = faces(2,i);
        float scalar_a = (distances(a)-dminimum)/(dmaximum - dminimum);
        Vector3f color_a = colorMap(scalar_a);
        glColor3f (color_a(0), color_a(1), color_a(2));
        glVertex3f(vertices(0,a), vertices(1,a), vertices(2,a));

        float scalar_b = (distances(b)-dminimum)/(dmaximum - dminimum);
        Vector3f color_b = colorMap(scalar_b);
        glColor3f (color_b(0), color_b(1), color_b(2));
        glVertex3f(vertices(0,b), vertices(1,b), vertices(2,b));

        float scalar_c = (distances(c)-dminimum)/(dmaximum - dminimum);
        Vector3f color_c = colorMap(scalar_c);
        glColor3f (color_c(0), color_c(1), color_c(2));
        glVertex3f(vertices(0,c), vertices(1,c), vertices(2,c));
    }
    glEnd ( );

    glFlush ( );
}

void displayFcnSIHKS (void)
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (0.0, 0.0, 0.4);

    glBegin (GL_TRIANGLES);
    for (int i=0; i<faces.cols(); i++)
    {
        int a=0, b=0, c=0;
        a = faces(0,i);
        b = faces(1,i);
        c = faces(2,i);

        float scalar_a = (normSIHKS(a)-nminimum)/(nmaximum - nminimum);
        Vector3f color_a = colorMap(scalar_a);
        glColor3f (color_a(0), color_a(1), color_a(2));
        glVertex3f(vertices(0,a), vertices(1,a), vertices(2,a));

        float scalar_b = (normSIHKS(b)-nminimum)/(nmaximum - nminimum);
        Vector3f color_b = colorMap(scalar_b);
        glColor3f (color_b(0), color_b(1), color_b(2));
        glVertex3f(vertices(0,b), vertices(1,b), vertices(2,b));

        float scalar_c = (normSIHKS(c)-nminimum)/(nmaximum - nminimum);
        Vector3f color_c = colorMap(scalar_c);
        glColor3f (color_c(0), color_c(1), color_c(2));
        glVertex3f(vertices(0,c), vertices(1,c), vertices(2,c));
    }
    glEnd ( );

    glFlush ( );
}

void displayFcnVote (void)
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (0.0, 0.0, 0.4);

    glBegin (GL_TRIANGLES);
    for (int i=0; i<faces.cols(); i++)
    {
        int a=0, b=0, c=0;
        a = faces(0,i);
        b = faces(1,i);
        c = faces(2,i);
        float scalar_a = (vote(a)-vminimum)/(vmaximum - vminimum);
        Vector3f color_a = colorMap(scalar_a);
        glColor3f (color_a(0), color_a(1), color_a(2));
        glVertex3f(vertices(0,a), vertices(1,a), vertices(2,a));

        float scalar_b = (vote(b)-vminimum)/(vmaximum - vminimum);
        Vector3f color_b = colorMap(scalar_b);
        glColor3f (color_b(0), color_b(1), color_b(2));
        glVertex3f(vertices(0,b), vertices(1,b), vertices(2,b));

        float scalar_c = (vote(c)-vminimum)/(vmaximum - vminimum);
        Vector3f color_c = colorMap(scalar_c);
        glColor3f (color_c(0), color_c(1), color_c(2));
        glVertex3f(vertices(0,c), vertices(1,c), vertices(2,c));
    }
    glEnd ( );

    glFlush ( );
}

void reshapeFcn (GLint newWidth, GLint newHeight)
{
    glViewport (0, 0, newWidth, newHeight);
    winWidth = newWidth;
    winHeight = newHeight;
}

bool loadOFF(const char *path, vector<Vector3f> &data, Matrix3Xf &vertices, Matrix3Xi &faces)
{
    FILE *file = fopen(path, "r");
    if( file == NULL )
    {
        printf("Cannot open the file !\n");
        getchar();
        return false;
    }
    char lineHeader[128];
    int res = fscanf(file, "%s", lineHeader);
    if( strcmp( lineHeader, "OFF" ) != 0 )
    {
        printf("This is not an OFF file!\n");
        getchar();
        return false;
    }
    int nv, nf, ne;
    fscanf(file, "%d %d %d\n", &nv, &nf, &ne );
    Matrix3Xf temp_vertices(3, nv);
    Matrix3Xi temp_faces(3, nf);

    for (int i=0; i<nv; i++)
    {
        float x=0, y=0, z=0;
        fscanf(file, "%f %f %f\n", &x, &y, &z);
        temp_vertices(0,i) = x;
        temp_vertices(1,i) = y;
        temp_vertices(2,i) = z;
    }
    for (int i=0; i<nf; i++)
    {
        int n=0,a=0,b=0,c=0;
        fscanf(file, "%d %d %d %d\n", &n, &a, &b, &c);
        temp_faces(0,i) = a;
        data.push_back(temp_vertices.col(a));
        temp_faces(1,i) = b;
        data.push_back(temp_vertices.col(b));
        temp_faces(2,i) = c;
        data.push_back(temp_vertices.col(c));
    }
    vertices = temp_vertices;
    faces = temp_faces;

    fclose(file);
    return true;
}

bool loadPID(const char *path, vector<int> &pid)
{
    int data;
    ifstream fin;

    fin.open(path ,ios::in);
    assert (!fin.fail( ));
    fin >> data;
    pid.push_back(data);

    while (!fin.eof( ))
    {
         fin >> data;
         pid.push_back(data);
    }
    fin.close( );

    return true;
}

bool loadPrediction(const char *path, vector<float> &val)
{
    float data;
    ifstream fin;

    fin.open(path ,ios::in);
    assert (!fin.fail( ));

    string dummyLine;
    getline(fin, dummyLine);

    fin >> data;
    val.push_back(data);

    while (!fin.eof( ))
    {
         fin >> data;
         val.push_back(data);
    }
    fin.close( );

    return true;
}

int main (int argc, char** argv)
{
    // 3,4,10,14,15,16,17,19,20
    const char * prefix = "./data/";
    const char * off = ".off";
    const char * pid = ".pid";
    int offlen = strlen(prefix) + strlen(argv[1]) + strlen(off) + 1;
    int pidlen = strlen(prefix) + strlen(argv[1]) + strlen(pid) + 1;

    char offfile[offlen];
    strcpy(offfile, prefix);
    strcat(offfile, argv[1]);
    strcat(offfile, off);
    char pidfile[pidlen];
    strcpy(pidfile, prefix);
    strcat(pidfile, argv[1]);
    strcat(pidfile, pid);

    bool res = loadOFF(offfile, data, vertices, faces);
    // bool res = loadOFF("4.off", data, vertices, faces);

    // ====================================================== HGD and SIHKS

    vector<int> pointid;
    bool pidload = loadPID(pidfile, pointid);
    // bool pidload = loadPID("4.pid", pid);
    sources.resize(pointid.size()-1);
    for (int iter = 0; iter < pointid.size()-1; iter++)
    {
        sources(iter) = 0;
        sources(iter) = pointid[iter]; // -1 or not
    }
    // cout << sources.norm() << endl;

    Heat heat;

    heat.setFaces(faces);
    heat.setVertices(vertices);
    heat.setSources(sources);
    heat.setTime(0.001);

    distances.resize(vertices.cols());
    for (int iter=0; iter<vertices.cols(); iter++)
        distances(iter) = 0;
    distances = heat.getDistances();
    dmaximum = distances.maxCoeff();
    dminimum = distances.minCoeff();
    // cout << dmaximum << endl;
    // cout << dminimum << endl;
    // cout << distances.norm() << endl;

    SIHKS.resize(vertices.cols(), 96);
    for (int iter=0; iter<vertices.cols(); iter++)
        for (int iterT=0; iterT<96; iterT++)
            SIHKS(iter, iterT) = 0;
    SIHKS = heat.getSIHKS();
    normSIHKS.resize(vertices.cols());
    for (int i=0; i<normSIHKS.rows(); i++)
        normSIHKS(i) = SIHKS.row(i).norm();
    nmaximum = normSIHKS.maxCoeff();
    nminimum = normSIHKS.minCoeff();
    // cout << nmaximum << endl;
    // cout << nminimum << endl;
    // cout << SIHKS.norm() << endl;

    // ====================================================== Random Forest Regression

    train_indices = sampling(vertices.cols(), 500);
    MatrixXf train_samples_SIHKS(500, 96);
    VectorXf train_samples_HGD(500);
    for (int iter=0; iter<500; iter++)
    {
        train_samples_SIHKS.row(iter) = SIHKS.row(train_indices(iter));
        train_samples_HGD(iter) = distances(train_indices(iter));
    }

    writeData(train_samples_SIHKS, train_samples_HGD, "part_train.txt");
    if (argc == 4)
        int trainning = train();


    test_indices = sources;
    MatrixXf test_samples_SIHKS(sources.size(), 96);
    VectorXf test_samples_HGD(sources.size());
    for (int iter=0; iter<sources.size(); iter++)
    {
        test_samples_SIHKS.row(iter) = SIHKS.row(test_indices(iter));
        test_samples_HGD(iter) = distances(test_indices(iter));
    }
    writeData(test_samples_SIHKS, test_samples_HGD, "test.txt");

    if (argc == 2)
    {
        int testing = test();

        vector<float> prediction;
        bool predictionload = loadPrediction("CG.prediction", prediction);
        // cout << sources.size() << endl;
        // cout << prediction.size() << endl;
        for (int i = 0; i < test_indices.size(); i++)
            test_samples_HGD(i) = prediction[i];
        // cout << test_samples_HGD << endl;
    }

    vote.resize(vertices.cols());
    for(int iter=0; iter<vertices.cols();iter++)
        vote(iter) = 0;
    float mu = 5;
    for (int i = 0; i < test_indices.size(); i++)
    {
        float weight = exp(-mu*test_samples_HGD(i)*test_samples_HGD(i));
        float threshold = test_samples_HGD(i)/50;
        for (int j=0; j < vertices.cols(); j++)
        {
            float error = abs(distances(j) - test_samples_HGD(i));
            if (abs(error) < threshold)
                vote(j) = vote(j) + weight;
        }
    }

    vmaximum = vote.maxCoeff();
    vminimum = vote.minCoeff();
    // cout << vote.norm() << endl;
    // cout << vminimum << endl;
    // cout << vmaximum << endl;

    // ====================================================== Display

    glutInit (&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);

    glutInitWindowPosition (50, 0);
    glutInitWindowSize(winWidth, winHeight);
    glutCreateWindow("CG Project Source");

    init();
    glutDisplayFunc(displayFcn);
    glutReshapeFunc(reshapeFcn);


    glutInitWindowPosition (500, 0);
    glutInitWindowSize(winWidth, winHeight);
    glutCreateWindow("CG Project HGD");

    init();
    glutDisplayFunc(displayFcnHGD);
    glutReshapeFunc(reshapeFcn);


    glutInitWindowPosition (50, 525);
    glutInitWindowSize(winWidth, winHeight);
    glutCreateWindow("CG Project SIHKS");

    init();
    glutDisplayFunc(displayFcnSIHKS);
    glutReshapeFunc(reshapeFcn);

//        glutInitWindowPosition (50, 525);
//        glutInitWindowSize(winWidth, winHeight);
//        glutCreateWindow("CG Project Train Samples");

//        init();
//        glutDisplayFunc(displayFcnTrain);
//        glutReshapeFunc(reshapeFcn);


//        glutInitWindowPosition (500, 525);
//        glutInitWindowSize(winWidth, winHeight);
//        glutCreateWindow("CG Project Test Samples");

//        init();
//        glutDisplayFunc(displayFcnTest);
//        glutReshapeFunc(reshapeFcn);

    glutInitWindowPosition (500, 525);
    glutInitWindowSize(winWidth, winHeight);
    glutCreateWindow("CG Project Vote");

    init();
    glutDisplayFunc(displayFcnVote);
    glutReshapeFunc(reshapeFcn);

    glutMainLoop();

    return 0;
}
